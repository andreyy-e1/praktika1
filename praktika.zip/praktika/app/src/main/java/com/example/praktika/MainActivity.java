package com.example.praktika;

import androidx.activity.result.ActivityResult;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_DECEIT = 0;
    private static final String TAG = "MainActivity";
    private static final String KEY_INDEX = "index";
    private Button mtrye_button;
    private Button mflse_button;
    private ImageButton mNext_button;
    private ImageButton mBak_button;
    private Button mDeceitButton;
    private TextView mQueshtionTextView;
    private Queshtion[] mQueshtionsBank = new Queshtion[]{
            new Queshtion(R.string.queshtion_android, true),
            new Queshtion(R.string.queshtion_linear, false),
            new Queshtion(R.string.queshtion_servis, false),
            new Queshtion(R.string.queshtion_res, true),
            new Queshtion(R.string.queshtion_manifest, true),
            new Queshtion(R.string.queshtion_google,true),
            new Queshtion(R.string.queshtion_44k, false),
            new Queshtion(R.string.queshtion_dex, true),
            new Queshtion(R.string.queshtion_idea,false),
            new Queshtion(R.string.queshtion_git, true),
    };
    private int mCurrentIndex = 0;
    private boolean mIsDeceier;
    @Override
    public void onStart(){
        super.onStart();
        Log.d(TAG, "onStart() Вызван");
    }
    @Override
    public void onPause(){
        super.onPause();
        Log.d(TAG, "onPause()вызван");
    }
    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG, "onResume() вызван");
    }
    @Override
    public void onStop(){
        super.onStop();
        Log.d(TAG, "onStop() вызван");
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "onDistroy");
    }
    private void updateQueshtion(){
        int queshtion = mQueshtionsBank[mCurrentIndex].getTextResId();
        mQueshtionTextView.setText(queshtion);
    }
    private void checkAnswer(boolean userPressedTrue) {
        boolean answerIsTrue =
                mQueshtionsBank[mCurrentIndex].isAnswerTrue();
        int messageResId = 0;
        if (mIsDeceier){
            messageResId = R.string.judgment_toast;
        } else {


            if (userPressedTrue == answerIsTrue) {
                messageResId = R.string.correct_clik;
            } else {
                messageResId = R.string.incorrect_clik;
            }
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d(TAG,"onCreate(Bundle)Вызван");



        setContentView(R.layout.activity_main);
        mQueshtionTextView =
                (TextView)findViewById(R.id.queshtion_name_view);
        mtrye_button = (Button) findViewById(R.id.trye_button);
        mtrye_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(true);
            }
        });
        mflse_button = (Button) findViewById(R.id.flse_button);
        mflse_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(false);
            }
        });
        mNext_button = (ImageButton)findViewById(R.id.next_button);
        mNext_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCurrentIndex = (mCurrentIndex + 1) % mQueshtionsBank.length;
                mIsDeceier = false;
                updateQueshtion();
            }
        });
        TextView textView = (TextView) findViewById(R.id.queshtion_name_view);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCurrentIndex = (mCurrentIndex + 1) % mQueshtionsBank.length;
                updateQueshtion();
            }
        });
        mBak_button = (ImageButton)findViewById(R.id.bak_button);
        mBak_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCurrentIndex = (mCurrentIndex - 1) % mQueshtionsBank.length;
                updateQueshtion();
            }
        });
        mDeceitButton = (Button)findViewById(R.id.deceit_button);
        mDeceitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean answerIsTrue = mQueshtionsBank[mCurrentIndex].isAnswerTrue();
                Intent i = DeceitActivity.newIntent(MainActivity.this, answerIsTrue);
                startActivityForResult(i, REQUEST_CODE_DECEIT);
            }
        });
        if (savedInstanceState != null){
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
        }
        updateQueshtion();
    }
    @Override
    public void onSaveInstanceState(Bundle saveInstanceState){
        super.onSaveInstanceState(saveInstanceState);
        Log.i(TAG, "onSaveInstanceState");
        saveInstanceState.putInt(KEY_INDEX, mCurrentIndex);
    }
    @Override
    protected void onActivityResult(int requesCode, int resultCode, Intent data) {
        super.onActivityResult(requesCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requesCode == REQUEST_CODE_DECEIT) {
            if (data == null) {
                return;
            }
            mIsDeceier = DeceitActivity.wasAnswerShown(data);
        }
    }
}